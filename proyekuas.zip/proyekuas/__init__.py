# Code reference: https://pyimagesearch.com/2021/04/17/your-first-image-classifier-using-k-nn-to-classify-images/
# Many thanks to Adrian Rosebrock from PyImageSearch :)

from preprocessing import SimplePreprocessor
from datasets import SimpleDatasetLoader