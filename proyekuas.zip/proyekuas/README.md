Ketik `python proyekuas/knn.py --dataset proyekuas/datasets/pepaya` di terminal untuk menjalankan kode.

SOURCE: [https://pyimagesearch.com/2021/04/17/your-first-image-classifier-using-k-nn-to-classify-images/]
